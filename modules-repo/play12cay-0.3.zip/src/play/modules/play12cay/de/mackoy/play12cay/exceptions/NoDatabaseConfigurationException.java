package de.mackoy.play12cay.exceptions;

public class NoDatabaseConfigurationException extends Exception {
	public NoDatabaseConfigurationException(String message){
		super(message);
	}
}
